package br.com.sistema.veiculosRh.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.sistema.veiculosRh.model.FuncionarioModel;
import br.com.sistema.veiculosRh.repository.FuncionarioRepository;

@Service
public class FuncionarioService {

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    public List<FuncionarioModel> listarTodos() {
        return funcionarioRepository.findAll();
    }

    public Optional<FuncionarioModel> buscarPorId(int id) {
        return funcionarioRepository.findById(id);
    }

    public FuncionarioModel salvar(FuncionarioModel funcionario) {
        return funcionarioRepository.save(funcionario);
    }

    public void excluir(int id) {
        funcionarioRepository.deleteById(id);
    }

    public List<FuncionarioModel> listarTopMotoristas() {
        return funcionarioRepository.findTopMotoristas();
    }

    public List<FuncionarioModel> listarFuncionariosPorMesAniversarioSemPenalidade(int mes) {
        return funcionarioRepository.findFuncionariosPorMesAniversarioSemPenalidade(mes);
    }

    public List<FuncionarioModel> listarFuncionariosComPenalizacao() {
        return funcionarioRepository.findFuncionariosComPenalizacao();
    }
}
