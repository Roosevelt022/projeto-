package br.com.sistema.veiculosRh.rest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.sistema.veiculosRh.model.FuncionarioModel;
import br.com.sistema.veiculosRh.service.FuncionarioService;

@RestController
@RequestMapping("/funcionarios")
public class FuncionarioController {

    @Autowired
    private FuncionarioService funcionarioService;

    @GetMapping
    public List<FuncionarioModel> listarTodos() {
        return funcionarioService.listarTodos();
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<FuncionarioModel> buscarPorId(@PathVariable int id) {
        Optional<FuncionarioModel> funcionario = funcionarioService.buscarPorId(id);
        return funcionario.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/top-motoristas")
    public List<FuncionarioModel> listarTopMotoristas() {
        return funcionarioService.listarTopMotoristas();
    }

    @GetMapping("/aniversario")
    public List<FuncionarioModel> listarFuncionariosPorMesAniversarioSemPenalidade(@RequestParam int mes) {
        return funcionarioService.listarFuncionariosPorMesAniversarioSemPenalidade(mes);
    }

    @GetMapping("/penalizados")
    public List<FuncionarioModel> listarFuncionariosComPenalizacao() {
        return funcionarioService.listarFuncionariosComPenalizacao();
    }

    
    @PostMapping
    public ResponseEntity<FuncionarioModel> salvar(@RequestBody FuncionarioModel funcionario) {
        FuncionarioModel funcionarioSalvo = funcionarioService.salvar(funcionario);
        return ResponseEntity.ok(funcionarioSalvo);
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity<FuncionarioModel> atualizar(@PathVariable int id, @RequestBody FuncionarioModel funcionario) {
        if (!funcionarioService.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        funcionario.setId(id);
        FuncionarioModel funcionarioAtualizado = funcionarioService.salvar(funcionario);
        return ResponseEntity.ok(funcionarioAtualizado);
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity<Void> excluir(@PathVariable int id) {
        if (!funcionarioService.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        funcionarioService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
