
package br.com.sistema.veiculosRh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeiculosRhApplication {

	public static void main(String[] args) {
		SpringApplication.run(VeiculosRhApplication.class, args);
	}

}
