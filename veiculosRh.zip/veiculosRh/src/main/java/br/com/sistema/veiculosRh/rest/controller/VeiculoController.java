package br.com.sistema.veiculosRh.rest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.sistema.veiculosRh.model.VeiculoModel;
import br.com.sistema.veiculosRh.service.VeiculoService;

@RestController
@RequestMapping("/veiculos")
public class VeiculoController {

    @Autowired
    private VeiculoService veiculoService;

    
    @GetMapping
    public List<VeiculoModel> listarTodos() {
        return veiculoService.listarTodos();
    }

    @GetMapping("/ano")
    public List<VeiculoModel> getVeiculosPorAno(@RequestParam int ano) {
        return veiculoService.listarVeiculosPorAno(ano);
    }

    @GetMapping("/modelo")
    public List<VeiculoModel> getVeiculosPorModelo(@RequestParam String modelo) {
        return veiculoService.listarVeiculosPorModelo(modelo);
    }

    @GetMapping("/top3-km")
    public List<VeiculoModel> getTop3VeiculosMaiorQuilometragem() {
        return veiculoService.listarTop3VeiculosMaiorQuilometragem();
    }

    @GetMapping("/buscar/{id}")
    public ResponseEntity<VeiculoModel> buscarPorId(@PathVariable int id) {
        Optional<VeiculoModel> veiculo = veiculoService.buscarPorId(id);
        return veiculo.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<VeiculoModel> salvar(@RequestBody VeiculoModel veiculo) {
        VeiculoModel veiculoSalvo = veiculoService.salvar(veiculo);
        return ResponseEntity.ok(veiculoSalvo);
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity<VeiculoModel> atualizar(@PathVariable int id, @RequestBody VeiculoModel veiculo) {
        if (!veiculoService.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        veiculo.setId(id);
        VeiculoModel veiculoAtualizado = veiculoService.salvar(veiculo);
        return ResponseEntity.ok(veiculoAtualizado);
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity<Void> excluir(@PathVariable int id) {
        if (!veiculoService.buscarPorId(id).isPresent()) {
            return ResponseEntity.notFound().build();
        }
        veiculoService.excluir(id);
        return ResponseEntity.noContent().build();
    }
}

