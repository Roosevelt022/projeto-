package br.com.sistema.veiculosRh.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.sistema.veiculosRh.model.FuncionarioModel;

public interface FuncionarioRepository extends JpaRepository<FuncionarioModel, Integer> {

        // Consulta para listar os funcionários que mais dirigiram veículos
    @Query("SELECT f FROM FuncionarioModel f ORDER BY f.quantidadeVezesDirigiu DESC")
    List<FuncionarioModel> findTopMotoristas();

    // Consulta para listar funcionários que fazem aniversário em um determinado mês e não têm penalização ativa
    @Query("SELECT f FROM FuncionarioModel f WHERE FUNCTION('MONTH', f.dataNascimento) = :mes AND f.penalizado = false")
    List<FuncionarioModel> findFuncionariosPorMesAniversarioSemPenalidade(@Param("mes") int mes);

    // Consulta para listar funcionários com penalizações
    @Query("SELECT f FROM FuncionarioModel f WHERE f.penalizado = true")
    List<FuncionarioModel> findFuncionariosComPenalizacao();
}

