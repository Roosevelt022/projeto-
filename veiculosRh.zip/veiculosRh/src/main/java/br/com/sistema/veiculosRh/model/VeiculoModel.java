package br.com.sistema.veiculosRh.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="veiculo")
public class VeiculoModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "modelo", length = 255, nullable = false)
    private String modelo;

    @Column(name = "marca", length = 255, nullable = false)
    private String marca;

    @Column(name = "categoria", length = 50, nullable = false)
    private String categoria; // Ex: moto, carro de passeio, utilitário, caminhão...

    @Column(name = "ano_fabricacao", nullable = false)
    private int anoFabricacao;

    @Column(name = "tipo_combustivel", length = 50, nullable = false)
    private String tipoCombustivel; // Ex: álcool, gasolina, diesel, elétrico

    @Column(name = "quantidade_passageiros", nullable = false)
    private int quantidadePassageiros;

    @Column(name = "habilitacao_minima", length = 10, nullable = false)
    private String habilitacaoMinima; // Ex: A, B, C, D, E

    @Column(name = "identificacao_veiculo", length = 10, nullable = false, unique = true)
    private String identificacaoVeiculo; // Ex: 01/2024

    @Column(name = "placa", length = 7, nullable = false, unique = true)
    private String placa;

    @Column(name = "quilometragem", nullable = false)
    private int quilometragem;
}

