package br.com.sistema.veiculosRh.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="funcionario")
public class FuncionarioModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "nome", length = 255, nullable = false)
    private String nome;

    @Column(name = "data_nascimento", nullable = false)
    private Date dataNascimento;

    @Column(name = "rg", length = 12, nullable = false, unique = true)
    private String rg;

    @Column(name = "habilitacao", length = 15, nullable = true, unique = true)
    private String habilitacao; // Número da habilitação, se houver

    @Column(name = "categoria_habilitacao", length = 2, nullable = true)
    private String categoriaHabilitacao; // Categoria da habilitação (A, B, C, D, E)

    @Column(name = "autorizado_dirigir", nullable = false)
    private boolean autorizadoDirigir;

    @Column(name = "penalizado", nullable = false)
    private boolean penalizado; // Indica se o funcionário sofreu alguma penalização

    @Column(name = "descricao_penalidade", length = 500, nullable = true)
    private String descricaoPenalidade; // Descrição da penalidade, se houver

    @Column(name = "periodo_penalidade", nullable = true)
    private Date periodoPenalidade; // Período da penalidade, se houver

    @Column(name = "quantidade_vezes_dirigiu", nullable = false)
    private int quantidadeVezesDirigiu; // Quantidade de vezes que o funcionário dirigiu
}
