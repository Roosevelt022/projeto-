package br.com.sistema.veiculosRh.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.sistema.veiculosRh.model.VeiculoModel;
import br.com.sistema.veiculosRh.repository.VeiculoRepository;

@Service
public class VeiculoService {

    @Autowired
    private VeiculoRepository veiculoRepository;

    public List<VeiculoModel> listarVeiculosPorAno(int ano) {
        return veiculoRepository.findAllByAnoFabricacao(ano);
    }

    public List<VeiculoModel> listarVeiculosPorModelo(String modelo) {
        return veiculoRepository.findAllByModelo(modelo);
    }

    public List<VeiculoModel> listarTop3VeiculosMaiorQuilometragem() {
        return veiculoRepository.findTop3VeiculosByQuilometragemDesc();
    }

    public List<VeiculoModel> listarTodos() {
        return veiculoRepository.findAll();
    }

    public Optional<VeiculoModel> buscarPorId(int id) {
        return veiculoRepository.findById(id);
    }

    public VeiculoModel salvar(VeiculoModel veiculo) {
        return veiculoRepository.save(veiculo);
    }

    public void excluir(int id) {
        veiculoRepository.deleteById(id);
    }
}
