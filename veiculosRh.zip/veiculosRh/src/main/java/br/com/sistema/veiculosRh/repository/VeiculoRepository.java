package br.com.sistema.veiculosRh.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.sistema.veiculosRh.model.VeiculoModel;

public interface VeiculoRepository extends JpaRepository<VeiculoModel, Integer> {
    
    @Query("SELECT v FROM VeiculoModel v WHERE v.anoFabricacao = :ano")
    List<VeiculoModel> findAllByAnoFabricacao(@Param("ano") int ano);

    @Query("SELECT v FROM VeiculoModel v WHERE v.modelo = :modelo")
    List<VeiculoModel> findAllByModelo(@Param("modelo") String modelo);

    @Query(value = "SELECT * FROM veiculo ORDER BY quilometragem DESC LIMIT 3", nativeQuery = true)
    List<VeiculoModel> findTop3VeiculosByQuilometragemDesc();
}
