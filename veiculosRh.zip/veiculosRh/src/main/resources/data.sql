INSERT INTO veiculo (modelo, marca, categoria, ano_fabricacao, tipo_combustivel, quantidade_passageiros, habilitacao_minima, identificacao_veiculo, placa, quilometragem)
VALUES 
    ('Gol', 'Volkswagen', 'Carro de Passeio', '2020', 'Gasolina', 5, 'B', '01/2020', 'ABC1234', 50000),
    ('Civic', 'Honda', 'Carro de Passeio', '2019', 'Gasolina', 5, 'B', '02/2019', 'DEF5678', 40000),
    ('Corolla', 'Toyota', 'Carro de Passeio', '2021', 'Gasolina', 5, 'B', '03/2021', 'GHI9012', 30000),
    ('F-150', 'Ford', 'Caminhão', '2018', 'Diesel', 3, 'C', '04/2018', 'JKL3456', 70000),
    ('HR-V', 'Honda', 'Utilitário', '2022', 'Gasolina', 5, 'B', '05/2022', 'MNO7890', 15000);

INSERT INTO funcionario (nome, data_nascimento, rg, habilitacao, categoria_habilitacao, autorizado_dirigir, penalizado, descricao_penalidade, periodo_penalidade, quantidade_vezes_dirigiu)
VALUES 
    ('João Silva', '1985-06-15', '12345678900', 'ABC123456', 'B', true, false, NULL, NULL, 50),
    ('Maria Oliveira', '1990-03-22', '23456789012', 'DEF234567', 'A', true, true, 'Multa por excesso de velocidade', '2024-05-01', 30),
    ('Pedro Santos', '1982-11-05', '34567890123', 'GHI345678', 'C', true, false, NULL, NULL, 70),
    ('Ana Costa', '1995-08-30', '45678901234', 'JKL456789', 'B', false, true, 'Dirigiu sem autorização', '2024-02-15', 20),
    ('Carlos Pereira', '1978-12-12', '56789012345', 'MNO567890', 'D', true, false, NULL, NULL, 40),
    ('Juliana Almeida', '1988-07-18', '67890123456', 'PQR678901', 'E', true, true, 'Uso indevido de veículo', '2023-10-10', 10),
    ('Ricardo Fernandes', '1992-09-25', '78901234567', 'STU789012', 'B', true, false, NULL, NULL, 60),
    ('Fernanda Lima', '1987-01-13', '89012345678', 'VWX890123', 'A', true, true, 'Condução sob efeito de álcool', '2024-04-01', 25),
    ('Marcelo Rocha', '1980-05-10', '90123456789', 'YZA901234', 'C', true, false, NULL, NULL, 55),
    ('Patrícia Martins', '1993-10-20', '01234567890', 'BCD012345', 'B', true, true, 'Acidente de trânsito', '2024-03-01', 35);
