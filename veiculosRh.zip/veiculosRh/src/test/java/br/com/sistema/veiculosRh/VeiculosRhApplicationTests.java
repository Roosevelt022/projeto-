package br.com.sistema.veiculosRh;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeiculosRhApplicationTests {

	@Test
	void contextLoads() {
	}

}
